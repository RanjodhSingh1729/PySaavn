from setuptools import setup

setup(
    name="pysaavn",
    install_requires=[
        "InquirerPy",
        "requests",
        "pyDes",
        "wget",
    ],
)
